import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export const authenticateApiKey = (req: Request, res: Response, next: NextFunction): void => {
  const apiKey = process.env.API_KEY;

  if (!apiKey) {
    logger.error('API_KEY não configurada no ambiente.');
    res.status(500).json({ success: false, error: 'Erro de configuração do servidor: API Key não definida.' });
    return;
  }

  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ success: false, error: 'Autenticação necessária. Use o formato Authorization: Bearer SEU_API_KEY.' });
    return;
  }

  const token = authHeader.split(' ')[1];

  if (token !== apiKey) {
    res.status(403).json({ success: false, error: 'API Key inválida.' });
    return;
  }

  next();
};

