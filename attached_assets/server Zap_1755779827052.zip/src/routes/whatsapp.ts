import { Router, Request, Response } from "express";
import { whatsappService } from "../whatsapp";
import { logger } from "../utils/logger";

const router = Router();

// Rota para iniciar conexão
router.post("/connect", async (req: Request, res: Response): Promise<void> => {
  try {
    await whatsappService.startConnection();
    
    res.json({
      success: true,
      message: "Tentativa de conexão iniciada",
      data: {
        status: whatsappService.getConnectionStatus()
      }
    });

  } catch (error: any) {
    logger.error("Erro ao iniciar conexão:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Erro interno do servidor"
    });
  }
});

// Rota para enviar mensagem
router.post("/send-message", async (req: Request, res: Response): Promise<void> => {
  try {
    const { number, message } = req.body;

    if (!number || !message) {
      res.status(400).json({
        success: false,
        error: "Número e mensagem são obrigatórios"
      });
      return;
    }

    // Validar formato do número
    const phoneRegex = /^[1-9]\d{1,14}$/;
    const cleanNumber = number.replace(/\D/g, "");
    
    if (!phoneRegex.test(cleanNumber)) {
      res.status(400).json({
        success: false,
        error: "Formato de número inválido"
      });
      return;
    }

    await whatsappService.sendMessage(cleanNumber, message);
    
    res.json({
      success: true,
      message: "Mensagem enviada com sucesso",
      data: {
        number: cleanNumber,
        message: message
      }
    });

  } catch (error: any) {
    logger.error("Erro ao enviar mensagem:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Erro interno do servidor"
    });
  }
});

// Rota para verificar status da conexão
router.get("/status", (req: Request, res: Response) => {
  try {
    const status = whatsappService.getConnectionStatus();
    
    res.json({
      success: true,
      data: {
        status: status,
        connected: status === "connected",
        timestamp: new Date().toISOString()
      }
    });

  } catch (error: any) {
    logger.error("Erro ao verificar status:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Erro interno do servidor"
    });
  }
});

// Rota para obter QR Code
router.get("/qrcode", async (req: Request, res: Response): Promise<void> => {
  try {
    const qrCodeImage = await whatsappService.getQRCode();
    const qrCodeText = whatsappService.getQRCodeText();
    
    if (!qrCodeImage && !qrCodeText) {
      res.json({
        success: true,
        message: "Nenhum QR Code disponível. WhatsApp pode já estar conectado.",
        data: {
          qrcode: null,
          qrcode_text: null,
          status: whatsappService.getConnectionStatus()
        }
      });
      return;
    }

    res.json({
      success: true,
      data: {
        qrcode: qrCodeImage, // Base64 data URL da imagem
        qrcode_text: qrCodeText, // Texto do QR code
        status: whatsappService.getConnectionStatus()
      }
    });

  } catch (error: any) {
    logger.error("Erro ao obter QR Code:", error);
    res.status(500).json({
      success: false,
      error: error.message || "Erro interno do servidor"
    });
  }
});

export default router;

