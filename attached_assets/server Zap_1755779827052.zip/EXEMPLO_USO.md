# Exemplo de Uso da WhatsApp API

## 1. Iniciar a API

```bash
cd whatsapp-api
npm install
npm run dev
```

A API estará disponível em: `http://localhost:3000`

## 2. Verificar se a API está funcionando

```bash
curl http://localhost:3000/
```

**Resposta esperada:**
```json
{
  "success": true,
  "message": "WhatsApp API está funcionando",
  "version": "1.0.0",
  "endpoints": {
    "POST /api/connect": "Iniciar conexão com WhatsApp",
    "POST /api/send-message": "Enviar mensagem",
    "GET /api/status": "Verificar status da conexão",
    "GET /api/qrcode": "Obter QR Code para conexão"
  }
}
```

## 3. Iniciar conexão com WhatsApp

```bash
curl -X POST http://localhost:3000/api/connect
```

**Resposta esperada:**
```json
{
  "success": true,
  "message": "Tentativa de conexão iniciada",
  "data": {
    "status": "connecting"
  }
}
```

## 4. Obter QR Code para conectar

```bash
curl http://localhost:3000/api/qrcode
```

**Resposta esperada:**
```json
{
  "success": true,
  "data": {
    "qrcode": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
    "qrcode_text": "1@ABC123...",
    "status": "connecting"
  }
}
```

- O campo `qrcode` contém a imagem em base64 que pode ser exibida diretamente no navegador
- O campo `qrcode_text` contém o texto do QR code
- Escaneie o QR code com seu WhatsApp

## 5. Verificar status da conexão

```bash
curl http://localhost:3000/api/status
```

**Resposta quando conectado:**
```json
{
  "success": true,
  "data": {
    "status": "connected",
    "connected": true,
    "timestamp": "2025-01-20T10:30:00.000Z"
  }
}
```

## 6. Enviar mensagem

```bash
curl -X POST http://localhost:3000/api/send-message \
  -H "Content-Type: application/json" \
  -d '{
    "number": "558387606350",
    "message": "*Olá!* \n\nEsta é uma mensagem de *teste* com *negrito* e alguns emojis! ✨🚀😊\n\nEspero que funcione perfeitamente! 😉"
  }'
```

**Resposta esperada:**
```json
{
  "success": true,
  "message": "Mensagem enviada com sucesso",
  "data": {
    "number": "558387606350",
    "message": "*Olá!* \n\nEsta é uma mensagem de *teste* com *negrito* e alguns emojis! ✨🚀😊\n\nEspero que funcione perfeitamente! 😉"
  }
}
```

## Fluxo Completo de Uso

1. **Inicie a API** → `npm run dev`
2. **Inicie a conexão** → `POST /api/connect`
3. **Obtenha o QR Code** → `GET /api/qrcode`
4. **Escaneie o QR Code** com seu WhatsApp
5. **Verifique o status** → `GET /api/status` (deve retornar "connected")
6. **Envie mensagens** → `POST /api/send-message`

## Códigos de Status

- `disconnected`: WhatsApp não está conectado
- `connecting`: Tentando conectar (QR Code disponível)
- `connected`: WhatsApp conectado e pronto para enviar mensagens

## Formato do Número

O número deve estar no formato internacional sem símbolos:
- ✅ **Correto**: `558387606350` (Brasil: 55 + DDD + número)
- ❌ **Incorreto**: `+55 (83) 8760-6350`

## Recursos Suportados

- ✅ Texto simples
- ✅ Texto formatado (*negrito*)
- ✅ Emojis
- ✅ Quebras de linha
- ✅ Reconexão automática
- ✅ QR Code em base64

