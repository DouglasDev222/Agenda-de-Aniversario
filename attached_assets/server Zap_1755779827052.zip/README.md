# WhatsApp API com Baileys

API REST para automação do WhatsApp usando a biblioteca Baileys.

## Funcionalidades

- ✅ Envio de mensagens via API REST
- ✅ Verificação do status de conexão
- ✅ Geração e visualização de QR Code para conexão
- ✅ Reconexão automática
- ✅ Logs detalhados

## Instalação

1. Clone o repositório
2. Instale as dependências:
```bash
npm install
```

3. Execute em modo de desenvolvimento:
```bash
npm run dev
```

   A API estará disponível em: `http://localhost:3001` (ou a URL pública: `https://3001-izwqtok7crrdej7balbof-bd5d5453.manusvm.computer`)

4. Para produção:
```bash
npm run build
npm start
```

## Endpoints da API

### 1. Health Check
```
GET /
```
Retorna informações básicas da API.

### 2. Iniciar Conexão
```
POST /api/connect
```
Inicia a conexão com o WhatsApp. Use esta rota primeiro antes de obter o QR Code.

**Resposta de Sucesso:**
```json
{
    "success": true,
    "message": "Tentativa de conexão iniciada",
    "data": {
        "status": "connecting"
    }
}
```

### 3. Enviar Mensagem
```
POST /api/send-message
```

**Body:**
```json
{
    "number": "558387606350",
    "message": "*Olá!* \n\nEsta é uma mensagem de *teste* com *negrito* e alguns emojis! ✨🚀😊\n\nEspero que funcione perfeitamente! 😉"
}
```

**Resposta de Sucesso:**
```json
{
    "success": true,
    "message": "Mensagem enviada com sucesso",
    "data": {
        "number": "558387606350",
        "message": "*Olá!* \n\nEsta é uma mensagem de *teste*..."
    }
}
```

### 4. Status da Conexão
```
GET /api/status
```

**Resposta:**
```json
{
    "success": true,
    "data": {
        "status": "connected",
        "connected": true,
        "timestamp": "2025-01-20T10:30:00.000Z"
    }
}
```

Possíveis status:
- `disconnected`: Desconectado
- `connecting`: Conectando
- `connected`: Conectado

### 5. QR Code
```
GET /api/qrcode
```

**Resposta:**
```json
{
    "success": true,
    "data": {
        "qrcode": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...",
        "qrcode_text": "1@ABC123...",
        "status": "connecting"
    }
}
```

## Como Usar

1. **Inicie a API**
2. **Inicie a conexão**: `POST /api/connect`
3. **Obtenha o QR Code**: `GET /api/qrcode`
4. **Escaneie o QR Code** com seu WhatsApp
5. **Verifique o status**: `GET /api/status`
6. **Envie mensagens**: `POST /api/send-message`

## Formato do Número

O número deve estar no formato internacional sem símbolos:
- ✅ Correto: `558387606350` (Brasil: 55 + DDD + número)
- ❌ Incorreto: `+55 (83) 8760-6350`

## Recursos do WhatsApp Suportados

- Texto simples
- Texto formatado (negrito com `*texto*`)
- Emojis
- Quebras de linha

## Logs

A API gera logs detalhados de todas as operações:
- Conexões e desconexões
- Mensagens enviadas e recebidas
- Erros e exceções
- Status de QR Code

## Estrutura do Projeto

```
src/
├── index.ts          # Servidor Express principal
├── whatsapp.ts       # Serviço do WhatsApp (Baileys)
├── routes/
│   └── whatsapp.ts   # Rotas da API
└── utils/
    ├── logger.ts     # Configuração de logs
    └── message.ts    # Utilitários de mensagem
```

## Tecnologias Utilizadas

- **Node.js** + **TypeScript**
- **Express.js** - Framework web
- **Baileys** - Biblioteca do WhatsApp
- **Pino** - Sistema de logs
- **QRCode** - Geração de QR codes
- **CORS** - Suporte a requisições cross-origin

