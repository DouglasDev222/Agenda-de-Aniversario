import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious, PaginationEllipsis } from "@/components/ui/pagination";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import EmployeeModal from "@/components/modals/employee-modal";
import ImportEmployeesModal from "@/components/modals/import-employees-modal";
import type { Employee } from "@shared/schema";

export default function Employees() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | undefined>();
  const [deleteEmployee, setDeleteEmployee] = useState<Employee | undefined>();
  const [searchInput, setSearchInput] = useState(""); // Input value for immediate UI update
  const [searchQuery, setSearchQuery] = useState(""); // Debounced value for API calls
  const [positionFilter, setPositionFilter] = useState("");
  const [monthFilter, setMonthFilter] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize] = useState(20);

  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Debounce search input
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      setSearchQuery(searchInput);
    }, 500); // 500ms delay

    return () => clearTimeout(timeoutId);
  }, [searchInput]);

  // Reset to first page when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, positionFilter, monthFilter]);

  const { data: employeesData, isLoading, isFetching } = useQuery({
    queryKey: ["/api/employees", currentPage, pageSize, searchQuery, positionFilter, monthFilter],
    queryFn: () => api.employees.getAll({
      page: currentPage,
      limit: pageSize,
      search: searchQuery,
      position: positionFilter,
      month: monthFilter
    }),
    placeholderData: (previousData) => previousData, // Nova forma de manter dados anteriores
    staleTime: 1000 * 60 * 5, // Cache por 5 minutos
  });

  const employees = employeesData?.employees || [];
  const pagination = employeesData?.pagination;

  const deleteMutation = useMutation({
    mutationFn: (id: string) => api.employees.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "Sucesso",
        description: "Colaborador removido com sucesso!",
      });
      setDeleteEmployee(undefined);
    },
    onError: () => {
      toast({
        title: "Erro",
        description: "Falha ao remover colaborador. Tente novamente.",
        variant: "destructive",
      });
    },
  });

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(n => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  const calculateAge = (birthDate: string) => {
    const birth = new Date(birthDate + 'T00:00:00');
    const today = new Date();

    let currentAge = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    const dayDiff = today.getDate() - birth.getDate();

    // Se o aniversário ainda não aconteceu este ano, diminui 1 da idade
    if (monthDiff < 0 || (monthDiff === 0 && dayDiff < 0)) {
      currentAge--;
    }

    const nextAge = currentAge + 1;
    
    // Verifica se é aniversário hoje
    const isBirthdayToday = monthDiff === 0 && dayDiff === 0;

    return { currentAge, nextAge, isBirthdayToday };
  };

  const getNextBirthday = (birthDate: string) => {
    const birth = new Date(birthDate + 'T00:00:00');
    
    // Get today in Brazilian timezone - simplified
    const today = new Date();
    const thisYear = today.getFullYear();
    
    // Create birthday for this year
    let nextBirthday = new Date(thisYear, birth.getMonth(), birth.getDate());
    
    // Compare dates properly - if birthday passed this year, move to next year
    const todayDateOnly = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const birthdayThisYear = new Date(thisYear, birth.getMonth(), birth.getDate());
    
    if (birthdayThisYear < todayDateOnly) {
      nextBirthday = new Date(thisYear + 1, birth.getMonth(), birth.getDate());
    }

    // Calculate days difference
    const diffTime = nextBirthday.getTime() - todayDateOnly.getTime();
    const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));

    return {
      date: nextBirthday.toLocaleDateString("pt-BR"),
      days: diffDays
    };
  };

  const getDaysText = (days: number) => {
    if (days === 0) return '(hoje)';
    if (days === 1) return '(amanhã)';
    return `(em ${days} dias)`;
  };

  const getDaysColor = (days: number) => {
    if (days === 0) return 'text-red-600';
    if (days === 1) return 'text-orange-600';
    if (days <= 7) return 'text-green-600';
    return 'text-blue-600';
  };

  // Employees are now filtered and sorted on the server
  const filteredEmployees = employees;

  const handleEdit = (employee: Employee) => {
    setSelectedEmployee(employee);
    setIsModalOpen(true);
  };

  const handleAdd = () => {
    setSelectedEmployee(undefined);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedEmployee(undefined);
  };

  const handleDeleteClick = (employee: Employee) => {
    setDeleteEmployee(employee);
  };

  const handleDeleteConfirm = () => {
    if (deleteEmployee) {
      deleteMutation.mutate(deleteEmployee.id);
    }
  };

  // Componente dos filtros (estático)
  const SearchAndFilters = (
    <Card>
      <CardContent className="p-4 lg:p-6">
        <div className="space-y-4">
          {/* Search bar */}
          <div>
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-2">
              Buscar colaborador
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="fas fa-search text-gray-400"></i>
              </div>
              <Input
                id="search"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Digite o nome do colaborador..."
                className="pl-10"
              />
            </div>
          </div>

          {/* Filters row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por cargo
              </label>
              <Select value={positionFilter} onValueChange={setPositionFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os cargos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os cargos</SelectItem>
                  <SelectItem value="gerente">Gerente</SelectItem>
                  <SelectItem value="analista">Analista</SelectItem>
                  <SelectItem value="desenvolvedor">Desenvolvedor</SelectItem>
                  <SelectItem value="assistente">Assistente</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mês de aniversário
              </label>
              <Select value={monthFilter} onValueChange={setMonthFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os meses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os meses</SelectItem>
                  <SelectItem value="1">Janeiro</SelectItem>
                  <SelectItem value="2">Fevereiro</SelectItem>
                  <SelectItem value="3">Março</SelectItem>
                  <SelectItem value="4">Abril</SelectItem>
                  <SelectItem value="5">Maio</SelectItem>
                  <SelectItem value="6">Junho</SelectItem>
                  <SelectItem value="7">Julho</SelectItem>
                  <SelectItem value="8">Agosto</SelectItem>
                  <SelectItem value="9">Setembro</SelectItem>
                  <SelectItem value="10">Outubro</SelectItem>
                  <SelectItem value="11">Novembro</SelectItem>
                  <SelectItem value="12">Dezembro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="sm:col-span-2 lg:col-span-1 space-y-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">
                &nbsp;
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <Button onClick={handleAdd} className="w-full">
                  <i className="fas fa-plus mr-2"></i>
                  Adicionar
                </Button>
                <Button onClick={() => setIsImportModalOpen(true)} variant="outline" className="w-full">
                  <i className="fas fa-file-import mr-2"></i>
                  Importar
                </Button>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  // Remover o loading global - vamos usar loading localizado

  return (
    <div className="space-y-4 lg:space-y-6">
      {/* Search and Filters - Componente estático */}
      {SearchAndFilters}

      {/* Employees List - Componente que atualiza */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg lg:text-xl">Lista de Colaboradores</CardTitle>
            {isFetching && (
              <div className="flex items-center text-sm text-gray-500">
                <i className="fas fa-spinner fa-spin mr-2"></i>
                Atualizando...
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent className="p-0 relative">
          {isLoading && !employeesData && (
            <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center z-10">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                <span className="text-sm text-gray-600">Carregando colaboradores...</span>
              </div>
            </div>
          )}
          {/* Desktop Table View */}
          <div className="hidden lg:block">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Colaborador
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Data de Nascimento
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Idade
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Próximo Aniversário
                    </th>
                    <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Ações
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredEmployees?.map((employee) => {
                    const nextBirthday = getNextBirthday(employee.birthDate);

                    return (
                      <tr key={employee.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                              <span className="text-sm font-medium text-blue-600">
                                {getInitials(employee.name)}
                              </span>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">{employee.name}</div>
                              <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mt-1">
                                {employee.position}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {new Date(employee.birthDate + 'T00:00:00').toLocaleDateString('pt-BR')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          {(() => {
                            const ageInfo = calculateAge(employee.birthDate);
                            if (ageInfo.isBirthdayToday) {
                              return (
                                <div>
                                  <span className="font-semibold text-green-600">{ageInfo.currentAge} anos</span>
                                  <span className="text-xs text-green-600 block">🎂 Aniversário hoje!</span>
                                </div>
                              );
                            }
                            return (
                              <div>
                                <span className="font-medium">{ageInfo.currentAge} anos</span>
                                <span className="text-xs text-gray-500 block">próx: {ageInfo.nextAge} anos</span>
                              </div>
                            );
                          })()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="text-sm text-gray-900">{nextBirthday.date}</span>
                          <span className={`text-xs ml-2 ${getDaysColor(nextBirthday.days)}`}>
                            {getDaysText(nextBirthday.days)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <button
                            onClick={() => handleEdit(employee)}
                            className="text-indigo-600 hover:text-indigo-900 mr-3"
                          >
                            <i className="fas fa-edit"></i>
                          </button>
                          <button
                            onClick={() => handleDeleteClick(employee)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <i className="fas fa-trash"></i>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Card View */}
          <div className="lg:hidden">
            <div className="divide-y divide-gray-200">
              {filteredEmployees?.map((employee) => {
                const nextBirthday = getNextBirthday(employee.birthDate);

                return (
                  <div key={employee.id} className="p-4 hover:bg-gray-50">
                    <div className="flex items-start space-x-3">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-sm font-medium text-blue-600">
                          {getInitials(employee.name)}
                        </span>
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h3 className="text-sm font-medium text-gray-900 truncate">
                              {employee.name}
                            </h3>
                            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800 mt-1">
                              {employee.position}
                            </span>
                          </div>

                          <div className="flex space-x-2 ml-2">
                            <button
                              onClick={() => handleEdit(employee)}
                              className="p-2 text-indigo-600 hover:text-indigo-900 hover:bg-indigo-50 rounded-lg"
                            >
                              <i className="fas fa-edit text-sm"></i>
                            </button>
                            <button
                              onClick={() => handleDeleteClick(employee)}
                              className="p-2 text-red-600 hover:text-red-900 hover:bg-red-50 rounded-lg"
                            >
                              <i className="fas fa-trash text-sm"></i>
                            </button>
                          </div>
                        </div>

                        <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                          <div>
                            <span className="text-gray-500">Nascimento:</span>
                            <p className="text-gray-900 font-medium">
                              {new Date(employee.birthDate + 'T00:00:00').toLocaleDateString('pt-BR')}
                            </p>
                          </div>
                          <div>
                            <span className="text-gray-500">Idade:</span>
                            <div className="text-gray-900 font-medium">
                              {(() => {
                                const ageInfo = calculateAge(employee.birthDate);
                                if (ageInfo.isBirthdayToday) {
                                  return (
                                    <div>
                                      <span className="font-semibold text-green-600">{ageInfo.currentAge} anos</span>
                                      <span className="text-xs text-green-600 block">🎂 Aniversário hoje!</span>
                                    </div>
                                  );
                                }
                                return (
                                  <div>
                                    <span>{ageInfo.currentAge} anos</span>
                                    <span className="text-xs text-gray-500 block">próx: {ageInfo.nextAge} anos</span>
                                  </div>
                                );
                              })()}
                            </div>
                          </div>
                          <div className="col-span-2">
                            <span className="text-gray-500">Próximo aniversário:</span>
                            <p className="text-gray-900 font-medium">
                              {nextBirthday.date}
                              <span className={`ml-2 ${getDaysColor(nextBirthday.days)}`}>
                                {getDaysText(nextBirthday.days)}
                              </span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Empty State */}
          {filteredEmployees?.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <i className="fas fa-users text-4xl mb-4 text-gray-300"></i>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Nenhum colaborador encontrado</h3>
              <p className="text-sm">Tente ajustar os filtros ou adicione novos colaboradores.</p>
            </div>
          )}
        </CardContent>
        
        {/* Pagination */}
        {pagination && pagination.totalPages > 1 && (
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 border-t">
            <div className="text-sm text-gray-500">
              Mostrando {((pagination.page - 1) * pagination.limit) + 1} até{" "}
              {Math.min(pagination.page * pagination.limit, pagination.total)} de{" "}
              {pagination.total} colaboradores
            </div>
            
            <Pagination className="mx-0 w-auto">
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      if (pagination.hasPrev) {
                        setCurrentPage(currentPage - 1);
                      }
                    }}
                    className={!pagination.hasPrev ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
                
                {/* Page numbers */}
                {(() => {
                  const pages = [];
                  const showPages = 5; // Show 5 page numbers
                  const halfShow = Math.floor(showPages / 2);
                  
                  let startPage = Math.max(1, currentPage - halfShow);
                  let endPage = Math.min(pagination.totalPages, startPage + showPages - 1);
                  
                  // Adjust start if we're near the end
                  if (endPage - startPage + 1 < showPages) {
                    startPage = Math.max(1, endPage - showPages + 1);
                  }
                  
                  // Add first page and ellipsis if needed
                  if (startPage > 1) {
                    pages.push(
                      <PaginationItem key={1}>
                        <PaginationLink 
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(1);
                          }}
                          isActive={currentPage === 1}
                        >
                          1
                        </PaginationLink>
                      </PaginationItem>
                    );
                    
                    if (startPage > 2) {
                      pages.push(
                        <PaginationItem key="start-ellipsis">
                          <PaginationEllipsis />
                        </PaginationItem>
                      );
                    }
                  }
                  
                  // Add visible page numbers
                  for (let i = startPage; i <= endPage; i++) {
                    pages.push(
                      <PaginationItem key={i}>
                        <PaginationLink 
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(i);
                          }}
                          isActive={currentPage === i}
                        >
                          {i}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  }
                  
                  // Add last page and ellipsis if needed
                  if (endPage < pagination.totalPages) {
                    if (endPage < pagination.totalPages - 1) {
                      pages.push(
                        <PaginationItem key="end-ellipsis">
                          <PaginationEllipsis />
                        </PaginationItem>
                      );
                    }
                    
                    pages.push(
                      <PaginationItem key={pagination.totalPages}>
                        <PaginationLink 
                          href="#"
                          onClick={(e) => {
                            e.preventDefault();
                            setCurrentPage(pagination.totalPages);
                          }}
                          isActive={currentPage === pagination.totalPages}
                        >
                          {pagination.totalPages}
                        </PaginationLink>
                      </PaginationItem>
                    );
                  }
                  
                  return pages;
                })()}
                
                <PaginationItem>
                  <PaginationNext 
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      if (pagination.hasNext) {
                        setCurrentPage(currentPage + 1);
                      }
                    }}
                    className={!pagination.hasNext ? "pointer-events-none opacity-50" : "cursor-pointer"}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          </div>
        )}
      </Card>

      {/* Employee Modal */}
      <EmployeeModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        employee={selectedEmployee}
      />

      {/* Import Modal */}
      <ImportEmployeesModal
        isOpen={isImportModalOpen}
        onClose={() => setIsImportModalOpen(false)}
      />

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteEmployee} onOpenChange={() => setDeleteEmployee(undefined)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remover Colaborador</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja remover <strong>{deleteEmployee?.name}</strong>? 
              Esta ação não pode ser desfeita e todas as mensagens relacionadas também serão perdidas.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleteMutation.isPending ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2"></i>
                  Removendo...
                </>
              ) : (
                "Remover"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
